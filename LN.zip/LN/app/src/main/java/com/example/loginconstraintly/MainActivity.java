package com.example.loginconstraintly;

import static android.text.TextUtils.isEmpty;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import android.view.inputmethod.InputMethodManager;
import android.util.Patterns;
import android.view.View;

import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView createnewAccount;
    EditText username;
    EditText password;
    Button button;
    CheckBox rememberMe;



    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;


    @Override
    protected  void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createnewAccount = findViewById(R.id.createNewAccount);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        button = findViewById(R.id.button);
        rememberMe = (CheckBox) findViewById(R.id.rememberMe);



        sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        editor = sharedPreferences.edit();


        String name = sharedPreferences.getString("name", "");
        String passwords = sharedPreferences.getString("passowrd", "");
        ////////////////////////////////////////////////////////////////////

        password.setText(passwords);
        username.setText(name);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                checkDataEntered();
                ///////////////To Store Data////////////////////////////
                if (rememberMe.isChecked()) {

                    editor.putString("name", username.getText().toString());
                    editor.putString("passowrd", password.getText().toString());
                    editor.commit();
                } else {
                    editor.putString("email", "");
                    editor.putString("name", "");
                    editor.putString("passowrd", "");
                    editor.commit();
                }

                startActivity(new Intent(MainActivity.this,GrocceryList.class));



            }

            private void checkDataEntered() {
                if (isEmpty(username)) {

                    Toast.makeText(MainActivity.this, "You must enter name to register", Toast.LENGTH_SHORT).show();
                }
                if (isEmpty(password) == password.length() > 7) {
                    password.setError("Password must be 7 charcter");
                }
            }

            private boolean isEmpty(EditText editTextTextPersonName) {
                CharSequence str = editTextTextPersonName.getText().toString();
                return TextUtils.isEmpty(str);
            }


        });




        createnewAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, RegisterActivity.class));
            }
        });

    }}






   
    

