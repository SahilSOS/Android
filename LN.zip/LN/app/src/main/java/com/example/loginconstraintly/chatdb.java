package com.example.loginconstraintly;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class chatdb extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "InfoDatabase.db";
    public static final String TABLE_NAME = "list";



    public chatdb( Context context ) {
        super(context,DATABASE_NAME,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table list" + "(id integer primary key autoincrement , title text,description text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists list");
        onCreate(db);

    }

    public int insert(String list , String description){
        SQLiteDatabase sq = this.getWritableDatabase();
        ContentValues cn = new ContentValues();
        Log.d("TAG", "insert: "+list +" "+description);
        cn.put("title", list);
        cn.put("description", description);
       int  result = (int) sq.insert("list",null,cn);
        Log.e("TAG", "insert: "+cn );

        return result;
    }

    @SuppressLint("Range")
    public List<GroceryModal> getList()
    {
        List<GroceryModal> groceryModals=new ArrayList<>();

        SQLiteDatabase sq=this.getReadableDatabase();
        Cursor csr=sq.rawQuery("select * from "+ TABLE_NAME,null);
        csr.moveToFirst();
        while (!csr.isAfterLast())
        {
            groceryModals.add(new GroceryModal(csr.getString(csr.getColumnIndex("title")),csr.getString(csr.getColumnIndex("description"))));
            csr.moveToNext();
        }

        if(csr!=null)
        {
            csr.close();
        }

        return groceryModals;
    }


}
