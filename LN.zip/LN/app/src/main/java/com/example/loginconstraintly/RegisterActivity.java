package com.example.loginconstraintly;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.cast.framework.media.ImagePicker;
import com.google.android.material.floatingactionbutton.FloatingActionButton;



import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;


public class RegisterActivity extends AppCompatActivity {


    TextView Alreadyhaveaccount;
    CircleImageView imageView;
    FloatingActionButton changeProfile;


    EditText editTextTextPersonName;
    EditText inputemail;
    EditText inputPassword;
    EditText inputPassword2;


    CheckBox checkBox;
    Button button;
    AlertDialog dialog;
    private static final int IMAGE_PICK = 1;
    private static final int IMAGE_CAPTURE = 2;
    private Bitmap profile_imageBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        editTextTextPersonName = findViewById(R.id.editTextTextPersonName);
        inputemail = findViewById(R.id.username);
        inputPassword = findViewById(R.id.password);
        inputPassword2 = findViewById(R.id.inputPassword2);
        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkDataEntered();
            }

            private void checkDataEntered() {


                if (isEmpty(editTextTextPersonName)) {

                    Toast.makeText(RegisterActivity.this, "You must enter name to register", Toast.LENGTH_SHORT).show();
                } else if (isEmail(inputemail) == false) {
                    inputemail.setError("Enter valid email!");
                } else if (isEmpty(inputPassword) == inputPassword.length() > 7) {
                    inputPassword.setError("Password must be 7 charcter");
                } else if (isEmpty(inputPassword2) == !inputPassword2.equals(inputPassword)) {
                    inputPassword2.setError("Password not match");
                }


            }

            private boolean isEmpty(EditText editTextTextPersonName) {
                CharSequence str = editTextTextPersonName.getText().toString();
                return TextUtils.isEmpty(str);
            }

            private boolean isEmail(EditText text) {
                CharSequence email = text.getText().toString();
                return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
            }


        });


        Alreadyhaveaccount = findViewById(R.id.Alreadyhaveaccount);

        checkBox = (CheckBox) findViewById(R.id.checkBox);
        button = (Button) findViewById(R.id.button);

        button.setEnabled(false);
        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkBox.isChecked()) {

                    button.setEnabled(true);
                } else if (!checkBox.isChecked()) {
                    button.setEnabled(false);
                }
            }
        });

        Alreadyhaveaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegisterActivity.this, RegisterActivity.class));
            }
        });

        imageView = findViewById(R.id.imageView);
        changeProfile = findViewById(R.id.changeProfile);
        changeProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view == changeProfile) {
                    dialog.show();
                }
            }
        });

        final String[] items = new String[] { "Take from camera",
                "Select from gallery" };
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.select_dialog_item, items);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Select Image");
        builder.setAdapter(adapter, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int item) {

                if (item == 0) {
                    Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(takePicture, 1);//zero can be replaced with any action code

                } else { // pick from file
                    //To pick photo from gallery

                    Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pickPhoto, 2);
                }
            }
        });

        dialog = builder.create();

        }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        switch (requestCode) {
            case 1:
                if (resultCode == RESULT_OK) {
                    Bundle extras = data.getExtras();
                    Bitmap imageBitmap = (Bitmap) extras.get("data");
                    imageView.setImageBitmap(imageBitmap);
                }

                break;
            case 2:
                if (resultCode == RESULT_OK) {
                    Uri selectedImage = data.getData();
                    imageView.setImageURI(selectedImage);
                }
                break;
        }
    }
}