package com.example.loginconstraintly;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EdgeEffect;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class create extends AppCompatActivity {


//    ListView listview1;
    chatdb cdb;
    EditText title, text;
    Button add;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        title=findViewById(R.id.title);
        text=findViewById(R.id.text);
        add=findViewById(R.id.add);

//        Log.e("TAG", "onCreate: "+str_title );

        cdb=new chatdb(this);





        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str_title=title.getText().toString();
                String str_desc=text.getText().toString();
                GroceryModal groceryModal=new GroceryModal(str_title,str_desc);
                int i=cdb.insert(str_title,str_desc);
                Log.e("TAG", "onClick: "+i );
                if(i!=0)
                {
                    Toast.makeText(create.this, "Data was inserted", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(create.this,GrocceryList.class);
                    startActivity(intent);
                }
            }
        });

    }


}