package com.example.loginconstraintly;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MyAdapter extends BaseAdapter {

    private final List<GroceryModal> arr;
    private final chatdb cdb;
    final GrocceryList crt;

    public MyAdapter(List<GroceryModal> arr, chatdb cdb, GrocceryList crt) {
        this.arr = arr;
        this.cdb = cdb;
        this.crt = crt;
    }



    @Override
    public int getCount() {
        return arr.size();
    }

    @Override
    public Object getItem(int i) {
        return arr.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        final View res= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.grocery_items,viewGroup,false);

        TextView titleTv, descTv;

        titleTv=res.findViewById(R.id.titleTv);
        descTv=res.findViewById(R.id.descTv);

//        GroceryModal groceryModal=new GroceryModal();

        Log.e("TAG", "getView:  arr : " + arr.get(i).getTitle() + "  " + arr.get(i).getDescription());
        titleTv.setText(arr.get(i).getTitle());
        descTv.setText(arr.get(i).getDescription());

        return res;
    }

    public void Clear() {
        arr.clear();
    }
}
