package com.example.loginconstraintly;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ActionBar;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;


public class GrocceryList extends AppCompatActivity {
    ListView listView;
    MyAdapter adp;

//    String arr[] = {"This is", "Item", "Item2", "another item", "another"};

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groccery_list);
        listView = findViewById(R.id.lv);

        Setdata();

//        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_list_item_1,arr);
//        listView.setAdapter(ad);
    }






    // Menu icons are inflated just as they were with actionbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return true;

    }


   //click on action button Add then opens a new activity

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int i=item.getItemId();
        if(i==R.id.add){
            startActivity(new Intent(GrocceryList.this,create.class));

        }



        return super.onOptionsItemSelected(item);
    }

    private void Setdata() {
        chatdb cdb= new chatdb(GrocceryList.this);
        List<GroceryModal> list=  cdb.getList();

        Log.e("TAG", "Setdata: " + list );

        adp= new MyAdapter(list,cdb,this);
        listView.setAdapter(adp);
    }
}
